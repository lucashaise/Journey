
function myFunction() {
  location.href = "#top";
}

  
function gotowhat() {
  location.href = "#whatis";
}

function gotot() {
  location.href = "#thery";
}

  
function gotoceli() {
  location.href = "#celi";
}

 function go() {
  location.href = "#o";
}
